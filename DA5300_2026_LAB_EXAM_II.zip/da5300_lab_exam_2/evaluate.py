import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def extract_section(output, heading, next_heading=None):
    """Return normalized non-empty lines in one named output section."""
    lines = [" ".join(line.split()) for line in output.splitlines() if line.strip()]
    try:
        start = lines.index(heading) + 1
    except ValueError:
        return None

    if next_heading is None:
        end = len(lines)
    else:
        try:
            end = lines.index(next_heading, start)
        except ValueError:
            return None
    return lines[start:end]


def evaluate_one(student, test_file):
    expected = test_file.with_suffix(test_file.suffix + ".expected").read_text()
    try:
        result = subprocess.run(
            [sys.executable, str(student), str(test_file)],
            capture_output=True,
            text=True,
            timeout=5,
        )
        actual = result.stdout
    except subprocess.TimeoutExpired:
        return False, False

    expected_degree = extract_section(expected, "DEGREES", "SHORTEST PATHS")
    expected_shortest = extract_section(expected, "SHORTEST PATHS")
    actual_degree = extract_section(actual, "DEGREES", "SHORTEST PATHS")
    actual_shortest = extract_section(actual, "SHORTEST PATHS")

    degree_ok = actual_degree is not None and actual_degree == expected_degree
    shortest_ok = actual_shortest is not None and actual_shortest == expected_shortest
    return degree_ok, shortest_ok


def evaluate_group(student, folder, prefix, count):
    degree_score = 0.0
    shortest_score = 0.0
    for i in range(1, count + 1):
        test_file = HERE / folder / f"{prefix}{i}.txt"
        degree_ok, shortest_ok = evaluate_one(student, test_file)
        degree_score += 0.5 * int(degree_ok)
        shortest_score += 0.5 * int(shortest_ok)
    return degree_score, shortest_score


def main():
    if len(sys.argv) != 2:
        print("Usage: python evaluate.py submissions_folder")
        sys.exit(2)

    folder = Path(sys.argv[1])
    if not folder.is_dir():
        print("Submission folder not found")
        sys.exit(2)

    header = (
        f"{'Roll number':<18}{'Pub Deg':>9}{'Pub SP':>8}"
        f"{'Priv Deg':>10}{'Priv SP':>9}{'Degree':>9}{'Shortest':>10}{'Total':>8}"
    )
    print(header)
    for student in sorted(folder.glob("*.py")):
        pub_d, pub_s = evaluate_group(student, "public_tests", "public", 5)
        prv_d, prv_s = evaluate_group(student, "private_tests", "private", 10)
        degree_total = pub_d + prv_d
        shortest_total = pub_s + prv_s
        total = degree_total + shortest_total
        print(
            f"{student.stem:<18}{pub_d:>5.1f}/2.5{pub_s:>6.1f}/2.5"
            f"{prv_d:>7.1f}/5{prv_s:>7.1f}/5"
            f"{degree_total:>6.1f}/7.5{shortest_total:>7.1f}/7.5{total:>5.1f}/15"
        )


if __name__ == "__main__":
    main()
