import sys
from pathlib import Path
from evaluate import evaluate_one

HERE = Path(__file__).resolve().parent


def main():
    student = HERE / "graph.py"
    if not student.exists():
        print("Save completed program as graph.py")
        sys.exit(1)

    degree_score = 0.0
    shortest_score = 0.0
    for i in range(1, 6):
        test_file = HERE / "public_tests" / f"public{i}.txt"
        degree_ok, shortest_ok = evaluate_one(student, test_file)
        degree_score += 0.5 * int(degree_ok)
        shortest_score += 0.5 * int(shortest_ok)
        print(
            f"Public test {i}: degree {'PASS' if degree_ok else 'FAIL'}; "
            f"shortest distance {'PASS' if shortest_ok else 'FAIL'}"
        )

    print(f"Degree score: {degree_score:.1f}/2.5")
    print(f"Shortest-distance score: {shortest_score:.1f}/2.5")
    print(f"Public total: {degree_score + shortest_score:.1f}/5")


if __name__ == "__main__":
    main()
