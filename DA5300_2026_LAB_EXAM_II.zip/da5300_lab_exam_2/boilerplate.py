import sys
import heapq


def read_input(filename):
    """
    Read the graph input file.

    Returns:
        directed: 1 for directed, 0 for undirected
        n: number of vertices
        edge_list: list of (u, v, weight) tuples
        source: source vertex

    Vertices are numbered 1..n. The edge_list is a Python list.
    """
    with open(filename, "r", encoding="utf-8") as f:
        data = list(map(int, f.read().split()))

    k = 0
    directed = data[k]
    n, m = data[k + 1], data[k + 2]
    k += 3

    edge_list = []
    for _ in range(m):
        u, v, w = data[k], data[k + 1], data[k + 2]
        edge_list.append((u, v, w))
        k += 3

    source = data[k]
    return directed, n, edge_list, source


def print_output(directed, degree, in_degree, out_degree, shortest_path):
    """
    Print the output in the required format.

    All degree and shortest_path arguments are lists indexed by vertex.
    Index 0 is unused; vertices are 1..n.
    """
    print("DEGREES")
    n = len(shortest_path) - 1

    if directed:
        for v in range(1, n + 1):
            print(v, in_degree[v], out_degree[v])
    else:
        for v in range(1, n + 1):
            print(v, degree[v])

    print("SHORTEST PATHS")
    for v in range(1, n + 1):
        if shortest_path[v] == float("inf"):
            print(v, "INF")
        else:
            print(v, int(shortest_path[v]))


# ----------------------------------------------------------------------
# Implement the following four functions.
# Use lists indexed by vertex (index 0 should remain unused).
# ----------------------------------------------------------------------

def calculate_undirected_degree(n, edge_list):
    """
    Return degree, a list of length n+1.
    degree[v] is the number of edges incident on vertex v.
    """
    # TODO: Implement this function.
    raise NotImplementedError


def calculate_directed_degree(n, edge_list):
    """
    Return (in_degree, out_degree), each a list of length n+1.
    """
    # TODO: Implement this function.
    raise NotImplementedError


def shortest_path_directed(n, edge_list, source):
    """
    Return shortest_path, a list of length n+1.
    Use Dijkstra's algorithm. Return float('inf') if unreachable.
    """
    # TODO: Implement this function.
    raise NotImplementedError


def shortest_path_undirected(n, edge_list, source):
    """
    Return shortest_path, a list of length n+1.
    Each edge can be traversed in both directions.
    Use Dijkstra's algorithm.
    """
    # TODO: Implement this function.
    raise NotImplementedError


def process_graph_file(filename):
    directed, n, edge_list, source = read_input(filename)

    # Lists are initialized/returned by the functions above.
    degree = [0] * (n + 1)
    in_degree = [0] * (n + 1)
    out_degree = [0] * (n + 1)

    if directed:
        in_degree, out_degree = calculate_directed_degree(n, edge_list)
        shortest_path = shortest_path_directed(n, edge_list, source)
    else:
        degree = calculate_undirected_degree(n, edge_list)
        shortest_path = shortest_path_undirected(n, edge_list, source)

    print_output(directed, degree, in_degree, out_degree, shortest_path)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python graph.py input.txt")
        sys.exit(2)
    process_graph_file(sys.argv[1])
