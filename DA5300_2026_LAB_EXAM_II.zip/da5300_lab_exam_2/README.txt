GRAPH LAB EXAM PACKAGE

Files:
  boilerplate.py          Student starter code
  public_tests/           5 public test cases and expected outputs
  public_evaluate.py      Student public-test evaluator
  evaluate.py             Examiner evaluator

FUNCTIONAL STRUCTURE

The input-reading and output-printing functions are supplied. Students
implement exactly four graph-algorithm functions:

1. calculate_undirected_degree(n, edge_list)
   Returns degree, a list of length n+1.

2. calculate_directed_degree(n, edge_list)
   Returns (in_degree, out_degree), two lists of length n+1.

3. shortest_path_directed(n, edge_list, source)
   Returns a list of shortest distances, length n+1.

4. shortest_path_undirected(n, edge_list, source)
   Returns a list of shortest distances, length n+1.

Input reading:
  read_input(filename) returns
  (directed, n, edge_list, source).
  edge_list is a list of (u, v, weight) tuples.

Output printing:
  print_output(directed, degree, in_degree, out_degree, shortest_path)
  is supplied and must not be modified.

LIST CONVENTION

All per-vertex arrays are Python lists of length n+1. Index 0 is unused;
the value for vertex v is stored at index v. An unreachable shortest
distance must be represented by float("inf").

INPUT FORMAT

directed
n m
u1 v1 w1
...
um vm wm
source

directed is 1 for directed and 0 for undirected. Vertices are 1..n.
All weights are non-negative. There are no self-loops or parallel edges.

OUTPUT FORMAT

The supplied print_output function prints DEGREES followed by SHORTEST
PATHS. Directed degree rows contain vertex, in-degree, out-degree.
Undirected degree rows contain vertex, degree. Shortest-path rows contain
only vertex and shortest distance; unreachable vertices are printed INF.
Path vertices are not required.

STUDENT WORKFLOW

Complete the four TODO functions in boilerplate.py, save the completed
program as graph.py, and run:
  python public_evaluate.py

Submit as ROLLNUMBER.py.

EXAMINER

Place submissions in a folder and run:
  python evaluate.py submissions

Each of the 15 tests is worth 1 mark, split equally: 0.5 mark for the
degree section and 0.5 mark for the shortest-distance section. The two
sections are evaluated independently, so an error in one does not forfeit
the marks for the other. Across all tests, degree computation is worth
7.5 marks and shortest distances are worth 7.5 marks. Whitespace-only
differences are ignored.
