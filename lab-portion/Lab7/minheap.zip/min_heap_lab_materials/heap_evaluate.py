import sys
from pathlib import Path

def insert(h,x):
    h.append(x); i=len(h)-1
    while i:
        p=(i-1)//2
        if h[p] <= h[i]: break
        h[p],h[i]=h[i],h[p]; i=p

def down(h,i):
    while True:
        l=2*i+1; r=2*i+2; m=i
        if l<len(h) and h[l]<h[m]: m=l
        if r<len(h) and h[r]<h[m]: m=r
        if m==i: break
        h[i],h[m]=h[m],h[i]; i=m

def delete(h,x):
    try: i=h.index(x)
    except ValueError: return
    last=h.pop()
    if i==len(h): return
    h[i]=last
    if i and h[i]<h[(i-1)//2]:
        while i:
            p=(i-1)//2
            if h[p]<=h[i]: break
            h[p],h[i]=h[i],h[p]; i=p
    else: down(h,i)

def extract(h):
    if not h: raise IndexError
    x=h[0]; last=h.pop()
    if h:
        h[0]=last; down(h,0)
    return x

def levels(h):
    ans=[]; start=0
    while start<len(h):
        end=min(2*start+1,len(h))
        ans.append([str(x) for x in h[start:end]])
        start=end
    return ans

def main():
    if len(sys.argv)!=5:
        print("Usage: python heap_evaluate.py input.txt heap.txt sorted.txt tree.txt")
        sys.exit(2)

    inp, hf, sf, tf=sys.argv[1:]
    lines=[x.strip() for x in Path(inp).read_text().splitlines() if x.strip()]
    hout=Path(hf).read_text().splitlines()
    sout=Path(sf).read_text().splitlines()

    if len(hout)!=len(lines):
        print("FAIL: heap.txt must have exactly one line per input line")
        sys.exit(1)
    if len(sout)!=len(lines):
        print("FAIL: sorted.txt must have exactly one line per input line")
        sys.exit(1)

    h=[]; expected_h=[]; expected_s=[]; expected_l=[]
    for i,line in enumerate(lines):
        vals=[int(x.strip()) for x in line.split(",") if x.strip()]
        if i%2==0:
            for x in vals: insert(h,x)
        else:
            for x in vals: delete(h,x)

        expected_h.append([str(x) for x in h])

        if any(h[(j-1)//2] > h[j] for j in range(1,len(h))):
            print(f"FAIL: reference heap construction invalid at line {i+1}")
            sys.exit(1)

        c=h.copy(); s=[]
        while c: s.append(str(extract(c)))
        expected_s.append(s)
        expected_l.append(levels(h))

    for i,(got,exp) in enumerate(zip(hout,expected_h)):
        g=[] if not got.strip() else [x.strip() for x in got.split(",")]
        if g!=exp:
            print(f"FAIL: heap.txt line {i+1}")
            print("Expected:",",".join(exp))
            print("Got     :",got)
            sys.exit(1)

    for i,(got,exp) in enumerate(zip(sout,expected_s)):
        g=[] if not got.strip() else [x.strip() for x in got.split(",")]
        if g!=exp:
            print(f"FAIL: sorted.txt line {i+1}")
            print("Expected:",",".join(exp))
            print("Got     :",got)
            sys.exit(1)

    blocks=[b for b in Path(tf).read_text().strip().split("\n\n") if b.strip()]
    if len(blocks)!=len(lines):
        print("FAIL: tree.txt must contain exactly one tree per input line")
        sys.exit(1)

    for i,(block,exp) in enumerate(zip(blocks,expected_l)):
        got=[line.split() for line in block.splitlines() if line.strip()]
        if got!=exp:
            print(f"FAIL: tree.txt tree {i+1}")
            print("Expected levels:",exp)
            print("Got levels     :",got)
            sys.exit(1)

    print("PASS: all Min-Heap checks succeeded.")

if __name__=="__main__":
    main()
