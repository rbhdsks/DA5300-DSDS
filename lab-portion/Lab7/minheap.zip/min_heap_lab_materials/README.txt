MIN-HEAP LAB MATERIALS

Student program:
python heap.py test1.txt heap.txt sorted.txt tree.txt

Evaluator:
python heap_evaluate.py test1.txt heap.txt sorted.txt tree.txt

Repeat for test2.txt and test3.txt.

The expected output files for all three tests are included.
The notebook demonstrates array representation, heapify-up,
heapify-down, insertion and extract-min.
