Run the student's programs:
python bst.py test1.txt inorder.txt preorder.txt postorder.txt tree.txt
python avl.py test1.txt inorder.txt preorder.txt postorder.txt tree.txt

Evaluate:
python evaluate.py bst test1.txt inorder.txt preorder.txt postorder.txt tree.txt
python evaluate.py avl test1.txt inorder.txt preorder.txt postorder.txt tree.txt

Repeat for test2.txt and test3.txt.
Expected files are included for both BST and AVL.
