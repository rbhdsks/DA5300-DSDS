import sys
from pathlib import Path

class N:
    def __init__(self,k): self.k=k; self.l=self.r=None; self.h=1
def H(n): return n.h if n else 0
def U(n): n.h=1+max(H(n.l),H(n.r))
def R(y):
    x=y.l;y.l=x.r;x.r=y;U(y);U(x);return x
def L(x):
    y=x.r;x.r=y.l;y.l=x;U(x);U(y);return y
def B(n): return H(n.l)-H(n.r)
def I(t,k,av):
    if not t:return N(k)
    if k<t.k:t.l=I(t.l,k,av)
    elif k>t.k:t.r=I(t.r,k,av)
    else:return t
    if not av:return t
    U(t);b=B(t)
    if b>1:
        if k>t.l.k:t.l=L(t.l)
        return R(t)
    if b<-1:
        if k<t.r.k:t.r=R(t.r)
        return L(t)
    return t
def D(t,k,av):
    if not t:return None
    if k<t.k:t.l=D(t.l,k,av)
    elif k>t.k:t.r=D(t.r,k,av)
    else:
        if not t.l:return t.r
        if not t.r:return t.l
        s=t.r
        while s.l:s=s.l
        t.k=s.k;t.r=D(t.r,s.k,av)
    if not av:return t
    U(t);b=B(t)
    if b>1:
        if B(t.l)<0:t.l=L(t.l)
        return R(t)
    if b<-1:
        if B(t.r)>0:t.r=R(t.r)
        return L(t)
    return t
def tr(t):
    a=[];b=[];c=[]
    def f(n):
        if not n:return
        b.append(n.k);f(n.l);a.append(n.k);f(n.r);c.append(n.k)
    f(t);return a,b,c
def lev(t):
    if not t:return []
    q=[t];o=[]
    while q:
        nq=[];o.append([str(x.k) for x in q])
        for x in q:
            if x.l:nq.append(x.l)
            if x.r:nq.append(x.r)
        q=nq
    return o
def main():
    if len(sys.argv)!=7:
        print("Usage: python evaluate.py bst|avl input.txt inorder.txt preorder.txt postorder.txt tree.txt");sys.exit(2)
    typ,inp,fi,fp,fq,ft=sys.argv[1:]
    av=(typ=="avl")
    if typ not in ("bst","avl"): print("FAIL: use bst or avl");sys.exit(1)
    lines=[x.strip() for x in Path(inp).read_text().splitlines() if x.strip()]
    outs=[[x.strip() for x in Path(f).read_text().splitlines()] for f in (fi,fp,fq)]
    if any(len(x)!=len(lines) for x in outs):
        print("FAIL: traversal files must have exactly one line per input line");sys.exit(1)
    t=None; ex=[]; el=[]
    for i,line in enumerate(lines):
        for k in [int(x.strip()) for x in line.split(",") if x.strip()]:
            t=I(t,k,av) if i%2==0 else D(t,k,av)
        ex.append(tr(t));el.append(lev(t))
    for j,name in enumerate(("inorder","preorder","postorder")):
        for i,e in enumerate(ex):
            got=[] if not outs[j][i] else [int(x.strip()) for x in outs[j][i].split(",")]
            if got!=e[j]:
                print(f"FAIL: {name}, line {i+1}: expected {e[j]}, got {got}");sys.exit(1)
    blocks=[b for b in Path(ft).read_text().strip().split("\n\n") if b.strip()]
    got=[[x.split() for x in b.splitlines() if x.strip()] for b in blocks]
    if len(got)!=len(el):
        print("FAIL: tree.txt must contain one tree per input line");sys.exit(1)
    for i,(g,e) in enumerate(zip(got,el)):
        if g!=e:
            print(f"FAIL: tree display, tree {i+1}: expected levels {e}, got {g}");sys.exit(1)
    print("PASS")
main()
