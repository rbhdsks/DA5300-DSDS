import sys
def post(pre, ino):
    if not pre: return []
    r=pre[0]; k=ino.index(r)
    return post(pre[1:k+1],ino[:k])+post(pre[k+1:],ino[k+1:])+[r]
if len(sys.argv)!=3:
    print("Usage: python order_evaluate.py prein.txt post.txt"); sys.exit(1)
with open(sys.argv[1]) as f: lines=[x.split() for x in f if x.strip()]
expected=post(lines[0],lines[1])
with open(sys.argv[2]) as f: got=f.read().split()
if got==expected: print("PASS")
else:
    print("FAIL\nExpected:", " ".join(expected), "\nGot:", " ".join(got)); sys.exit(1)
