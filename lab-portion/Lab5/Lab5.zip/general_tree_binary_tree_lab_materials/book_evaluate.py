import sys,re
if len(sys.argv)!=3:
    print("Usage: python book_evaluate.py book_titles.txt book_content.txt"); sys.exit(1)
with open(sys.argv[1]) as f: src=[x.strip() for x in f if x.strip()]
nums=[]
for line in src:
    m=re.match(r'^([0-9]+(?:\.[0-9]+)*)\.?\s+',line)
    if m: nums.append(m.group(1))
with open(sys.argv[2]) as f: out=[x.strip() for x in f if x.strip()]
missing=[n for n in nums if not any(re.match(r'^'+re.escape(n)+r'(\s|\.|$)',x) for x in out)]
if missing:
    print("FAIL: missing entries:",", ".join(missing)); sys.exit(1)
print("PASS: all numbered book entries are present.")
